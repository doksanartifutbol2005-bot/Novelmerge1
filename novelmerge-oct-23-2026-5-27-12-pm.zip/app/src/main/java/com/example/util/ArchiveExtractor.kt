package com.example.util

import android.content.Context
import android.net.Uri
import com.github.junrar.Junrar
import com.github.junrar.rarfile.FileHeader
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object ArchiveExtractor {

    private val IMAGE_EXTENSIONS = setOf("jpg", "jpeg", "png", "webp", "bmp", "gif")

    /**
     * Checks if a filename has an image extension
     */
    fun isImageFile(fileName: String): Boolean {
        val ext = fileName.substringAfterLast(".", "").lowercase()
        return ext in IMAGE_EXTENSIONS
    }

    /**
     * Extracts chapter archive (ZIP, RAR, CBZ) into destination chapter directory.
     * Normalizes image names in sorted sequence: page_001.jpg, page_002.jpg...
     */
    fun extractChapterArchive(
        context: Context,
        archiveUri: Uri,
        archiveFileName: String,
        targetChapterDir: File,
        tempDir: File
    ): List<File> {
        targetChapterDir.mkdirs()
        tempDir.mkdirs()
        val chapterTempDir = File(tempDir, "extract_${System.currentTimeMillis()}_${archiveFileName.hashCode()}")
        chapterTempDir.mkdirs()

        try {
            val isRar = archiveFileName.endsWith(".rar", ignoreCase = true)

            if (isRar) {
                extractRar(context, archiveUri, chapterTempDir)
            } else {
                // Default to ZIP / CBZ
                extractZip(context, archiveUri, chapterTempDir)
            }

            // Gather all extracted image files recursively
            val extractedImages = mutableListOf<File>()
            findImagesRecursively(chapterTempDir, extractedImages)

            // Sort using NaturalOrderComparator so page 1, page 2... page 10 are naturally sorted
            extractedImages.sortWith { f1, f2 ->
                val r1 = f1.relativeTo(chapterTempDir).path.replace("\\", "/")
                val r2 = f2.relativeTo(chapterTempDir).path.replace("\\", "/")
                NaturalOrderComparator().compare(r1, r2)
            }

            // Move and rename into target chapter dir as page_001.ext, page_002.ext...
            val finalPages = mutableListOf<File>()
            extractedImages.forEachIndexed { index, sourceFile ->
                val ext = sourceFile.extension.ifEmpty { "jpg" }
                val targetName = String.format("page_%04d.%s", index + 1, ext)
                val targetFile = File(targetChapterDir, targetName)
                sourceFile.copyTo(targetFile, overwrite = true)
                finalPages.add(targetFile)
            }

            return finalPages
        } finally {
            // Clean up temporary extracted folder
            chapterTempDir.deleteRecursively()
        }
    }

    private fun extractZip(context: Context, uri: Uri, destDir: File) {
        val inputStream = context.contentResolver.openInputStream(uri) ?: return
        ZipInputStream(BufferedInputStream(inputStream)).use { zis ->
            var entry: ZipEntry? = zis.nextEntry
            val buffer = ByteArray(16384)
            while (entry != null) {
                val cleanName = entry.name.replace("\\", "/")
                if (!entry.isDirectory && isImageFile(cleanName)) {
                    val targetFile = File(destDir, File(cleanName).name)
                    BufferedOutputStream(FileOutputStream(targetFile)).use { bos ->
                        var len: Int
                        while (zis.read(buffer).also { len = it } != -1) {
                            bos.write(buffer, 0, len)
                        }
                    }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
    }

    private fun extractRar(context: Context, uri: Uri, destDir: File) {
        // Copy URI to a temporary file because Junrar requires a java.io.File or File-backed stream
        val tempRarFile = File(destDir.parentFile, "temp_${System.currentTimeMillis()}.rar")
        try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(tempRarFile).use { output ->
                    input.copyTo(output)
                }
            }

            if (tempRarFile.exists() && tempRarFile.length() > 0) {
                val archive = com.github.junrar.Archive(tempRarFile)
                archive.use { arc ->
                    var header: FileHeader? = arc.nextFileHeader()
                    while (header != null) {
                        val headerName = header.fileName.replace("\\", "/")
                        if (!header.isDirectory && isImageFile(headerName)) {
                            val targetFile = File(destDir, File(headerName).name)
                            FileOutputStream(targetFile).use { fos ->
                                arc.extractFile(header, fos)
                            }
                        }
                        header = arc.nextFileHeader()
                    }
                }
            }
        } catch (e: Exception) {
            // In case RAR extraction encountered a special version or failed, attempt ZIP stream fallback
            try {
                extractZip(context, uri, destDir)
            } catch (_: Exception) {
                // rethrow or log
            }
        } finally {
            if (tempRarFile.exists()) {
                tempRarFile.delete()
            }
        }
    }

    private fun findImagesRecursively(folder: File, result: MutableList<File>) {
        val files = folder.listFiles() ?: return
        for (file in files) {
            if (file.isDirectory) {
                findImagesRecursively(file, result)
            } else if (file.isFile && isImageFile(file.name)) {
                result.add(file)
            }
        }
    }

    /**
     * Exports a novel into a single unified .cbz file (Comic Book Zip)
     */
    fun exportNovelAsUnifiedCbz(novelDir: File, outputStream: java.io.OutputStream) {
        ZipOutputStream(BufferedOutputStream(outputStream)).use { zos ->
            val chaptersDir = File(novelDir, "chapters")
            if (chaptersDir.exists() && chaptersDir.isDirectory) {
                val chapterFolders = chaptersDir.listFiles()?.filter { it.isDirectory }
                    ?.sortedWith { a, b -> NaturalOrderComparator().compare(a.name, b.name) }
                    ?: emptyList()

                val buffer = ByteArray(16384)
                var globalPageCount = 0

                for (chapterFolder in chapterFolders) {
                    val pages = chapterFolder.listFiles()?.filter { isImageFile(it.name) }
                        ?.sortedWith { a, b -> NaturalOrderComparator().compare(a.name, b.name) }
                        ?: emptyList()

                    for (page in pages) {
                        globalPageCount++
                        // Sequential global prefix ensures photo 1 of Chapter 2 strictly follows photo N of Chapter 1
                        val entryName = "${chapterFolder.name}/${String.format("%04d_%s", globalPageCount, page.name)}"
                        val entry = ZipEntry(entryName)
                        zos.putNextEntry(entry)
                        page.inputStream().use { pis ->
                            var len: Int
                            while (pis.read(buffer).also { len = it } != -1) {
                                zos.write(buffer, 0, len)
                            }
                        }
                        zos.closeEntry()
                    }
                }
            }
        }
    }
}
