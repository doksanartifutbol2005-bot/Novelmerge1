package com.example.util

import java.util.regex.Pattern

/**
 * Natural Order string comparator for sorting chapter and page filenames naturally
 * e.g., "Page 1", "Page 2", "Page 10" instead of "Page 1", "Page 10", "Page 2".
 */
class NaturalOrderComparator : Comparator<String> {
    override fun compare(s1: String?, s2: String?): Int {
        if (s1 == null && s2 == null) return 0
        if (s1 == null) return -1
        if (s2 == null) return 1

        var idx1 = 0
        var idx2 = 0
        val len1 = s1.length
        val len2 = s2.length

        while (idx1 < len1 && idx2 < len2) {
            val c1 = s1[idx1]
            val c2 = s2[idx2]

            if (c1.isDigit() && c2.isDigit()) {
                // Find complete numeric substrings
                val start1 = idx1
                while (idx1 < len1 && s1[idx1].isDigit()) idx1++
                val numStr1 = s1.substring(start1, idx1)

                val start2 = idx2
                while (idx2 < len2 && s2[idx2].isDigit()) idx2++
                val numStr2 = s2.substring(start2, idx2)

                // Compare numeric value
                try {
                    val n1 = numStr1.toLong()
                    val n2 = numStr2.toLong()
                    if (n1 != n2) {
                        return n1.compareTo(n2)
                    }
                } catch (_: NumberFormatException) {
                    val comp = numStr1.compareTo(numStr2)
                    if (comp != 0) return comp
                }

                // If values are equal, the one with fewer leading zeros comes first or tie-break by length
                if (numStr1.length != numStr2.length) {
                    return numStr1.length.compareTo(numStr2.length)
                }
            } else {
                val comp = c1.lowercaseChar().compareTo(c2.lowercaseChar())
                if (comp != 0) return comp
                idx1++
                idx2++
            }
        }

        return len1.compareTo(len2)
    }

    companion object {
        private val CHAPTER_NUMBER_REGEX = Pattern.compile("(?i)(?:ch(?:apter)?|bolum|bölüm|ep|c|#)?\\s*(\\d+(?:\\.\\d+)?)")

        /**
         * Detects chapter number from filename like "Chapter 05.rar", "Solo_Leveling_Ch_12.zip", "bölüm 3.rar"
         */
        fun extractChapterNumber(filename: String, fallbackIndex: Int): Int {
            val cleanName = filename.substringBeforeLast(".")
            val matcher = CHAPTER_NUMBER_REGEX.matcher(cleanName)
            var lastFound = fallbackIndex
            while (matcher.find()) {
                val group = matcher.group(1)
                if (group != null) {
                    val parsed = group.toDoubleOrNull()?.toInt() ?: fallbackIndex
                    if (parsed > 0) {
                        lastFound = parsed
                    }
                }
            }
            return lastFound
        }

        /**
         * Cleans up raw file name to readable title
         */
        fun cleanChapterTitle(filename: String, chapterIndex: Int): String {
            val nameWithoutExt = filename.substringBeforeLast(".")
                .replace("_", " ")
                .replace("-", " ")
                .trim()
            return if (nameWithoutExt.isNotBlank()) {
                nameWithoutExt.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
            } else {
                "Bölüm $chapterIndex"
            }
        }
    }
}
