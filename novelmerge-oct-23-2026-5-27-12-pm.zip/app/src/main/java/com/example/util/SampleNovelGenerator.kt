package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import java.io.File
import java.io.FileOutputStream

object SampleNovelGenerator {

    /**
     * Creates a demo visual novel "Yıldız Işığı Anıları" (Echoes of the Starlight)
     * with 3 sequential chapters and 3 illustrated visual novel pages each.
     */
    fun createSampleNovel(context: Context, baseDir: File): File {
        val novelId = "sample_visual_novel_starlight"
        val novelDir = File(baseDir, novelId)
        if (novelDir.exists() && File(novelDir, "cover.jpg").exists()) {
            return novelDir
        }
        novelDir.mkdirs()

        val chaptersDir = File(novelDir, "chapters")
        chaptersDir.mkdirs()

        // Generate Cover
        val coverFile = File(novelDir, "cover.jpg")
        generatePageBitmap(
            title = "YILDIZ IŞIĞI ANILARI",
            subtitle = "Kozmik Görsel Roman • Cilt 1",
            dialogue = "Yıldızlar kadim sırları fısıldarken, iki gezgin evrenin kalbine doğru yola çıktı...",
            chapterNum = 0,
            pageNum = 0,
            primaryColor = 0xFF7B2CBF.toInt(),
            secondaryColor = 0xFF00B4D8.toInt(),
            isCover = true
        ).saveTo(coverFile)

        val chapterConfigs = listOf(
            Triple(1, "Bölüm 1: Uyanış ve Keşif", listOf(
                "Harabelerin ortasında eski bir kristal parlamaya başladı.",
                "Eren: 'Bu sinyal... yüzyıllardır uykudaydı. Nasıl mümkün olabilir?'",
                "Gökyüzünde mor ışık hüzmeleri dans ederek bilinmeyen bir haritayı çizdi."
            )),
            Triple(2, "Bölüm 2: Galaktik Kapı", listOf(
                "Tapınağın derinliklerinde devasa bir portal belirdi.",
                "Alya: 'Eğer bu kapıdan geçersek geri dönüş olmayabilir.'",
                "Eren gülümsedi: 'Geriye dönmek için buraya gelmedik.'"
            )),
            Triple(3, "Bölüm 3: Sonsuz Evren", listOf(
                "Boyutlar arası köprü onları nebula denizinin ortasına taşıdı.",
                "Binlerce yıldız gemisi sessiz bir nöbet tutuyordu.",
                "Yeni bir çağın başlangıcı... Macera şimdi başlıyor!"
            ))
        )

        chapterConfigs.forEach { (chIndex, chTitle, pageTexts) ->
            val chFolder = File(chaptersDir, String.format("chapter_%03d", chIndex))
            chFolder.mkdirs()

            pageTexts.forEachIndexed { pageIdx, dialogue ->
                val pageFile = File(chFolder, String.format("page_%04d.jpg", pageIdx + 1))
                val prim = if (chIndex == 1) 0xFF5A189A.toInt() else if (chIndex == 2) 0xFF0077B6.toInt() else 0xFF0096C7.toInt()
                val sec = if (chIndex == 1) 0xFF9D4EDD.toInt() else if (chIndex == 2) 0xFF48CAE4.toInt() else 0xFFFFB703.toInt()

                generatePageBitmap(
                    title = chTitle,
                    subtitle = "Sayfa ${pageIdx + 1}",
                    dialogue = dialogue,
                    chapterNum = chIndex,
                    pageNum = pageIdx + 1,
                    primaryColor = prim,
                    secondaryColor = sec,
                    isCover = false
                ).saveTo(pageFile)
            }
        }

        return novelDir
    }

    private fun generatePageBitmap(
        title: String,
        subtitle: String,
        dialogue: String,
        chapterNum: Int,
        pageNum: Int,
        primaryColor: Int,
        secondaryColor: Int,
        isCover: Boolean
    ): Bitmap {
        val width = 1080
        val height = 1600
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Draw rich deep background gradient
        val bgPaint = Paint().apply {
            shader = LinearGradient(
                0f, 0f, width.toFloat(), height.toFloat(),
                intArrayOf(0xFF0F0E17.toInt(), primaryColor, 0xFF0D1B2A.toInt()),
                floatArrayOf(0f, 0.5f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        // Decorative starry background
        val starPaint = Paint().apply {
            color = Color.WHITE
            alpha = 180
            style = Paint.Style.FILL
        }
        val random = java.util.Random(title.hashCode().toLong() + pageNum * 31L)
        for (i in 0..120) {
            val sx = random.nextFloat() * width
            val sy = random.nextFloat() * height
            val r = random.nextFloat() * 3.5f + 1f
            starPaint.alpha = random.nextInt(180) + 70
            canvas.drawCircle(sx, sy, r, starPaint)
        }

        // Main Visual Novel Panel Frame
        val panelPaint = Paint().apply {
            color = 0xAA121124.toInt()
            style = Paint.Style.FILL
        }
        val borderPaint = Paint().apply {
            color = secondaryColor
            strokeWidth = 6f
            style = Paint.Style.STROKE
        }

        val panelTop = if (isCover) 240f else 200f
        val panelBottom = if (isCover) 1100f else 1150f
        val panelRect = RectF(70f, panelTop, width - 70f, panelBottom)
        canvas.drawRoundRect(panelRect, 32f, 32f, panelPaint)
        canvas.drawRoundRect(panelRect, 32f, 32f, borderPaint)

        // Inner glowing art shapes representing visual novel scene
        val glowPaint = Paint().apply {
            color = primaryColor
            alpha = 140
        }
        canvas.drawCircle(width / 2f, (panelTop + panelBottom) / 2f - 40f, 260f, glowPaint)

        val crystalPaint = Paint().apply {
            color = secondaryColor
            style = Paint.Style.FILL
        }
        // Draw fantasy crystal / star emblem
        val cx = width / 2f
        val cy = (panelTop + panelBottom) / 2f - 40f
        val path = Path().apply {
            moveTo(cx, cy - 140f)
            lineTo(cx + 80f, cy)
            lineTo(cx, cy + 140f)
            lineTo(cx - 80f, cy)
            close()
        }
        canvas.drawPath(path, crystalPaint)

        // Header Text
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = if (isCover) 64f else 46f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(title, width / 2f, if (isCover) 160f else 130f, titlePaint)

        val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = secondaryColor
            textSize = 32f
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(subtitle, width / 2f, if (isCover) 210f else 175f, subPaint)

        // Bottom Visual Novel Dialogue Box
        val dialogBoxRect = RectF(60f, 1220f, width - 60f, 1500f)
        val dialogBoxPaint = Paint().apply {
            color = 0xEE1E1838.toInt()
            style = Paint.Style.FILL
        }
        val dialogBorderPaint = Paint().apply {
            color = 0xFF9D4EDD.toInt()
            strokeWidth = 4f
            style = Paint.Style.STROKE
        }
        canvas.drawRoundRect(dialogBoxRect, 24f, 24f, dialogBoxPaint)
        canvas.drawRoundRect(dialogBoxRect, 24f, 24f, dialogBorderPaint)

        // Character Name Tag
        val nameTagRect = RectF(100f, 1180f, 360f, 1240f)
        val nameTagPaint = Paint().apply {
            color = 0xFF7B2CBF.toInt()
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(nameTagRect, 16f, 16f, nameTagPaint)

        val namePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 28f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        val speakerName = if (isCover) "ANLATICI" else if (pageNum % 2 == 1) "EREN" else "ALYA"
        canvas.drawText(speakerName, 230f, 1222f, namePaint)

        // Dialogue text wrapped
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 34f
            style = Paint.Style.FILL
        }

        // Simple text wrap
        val words = dialogue.split(" ")
        var line = ""
        var lineY = 1300f
        for (w in words) {
            val testLine = if (line.isEmpty()) w else "$line $w"
            if (textPaint.measureText(testLine) < 880f) {
                line = testLine
            } else {
                canvas.drawText(line, 100f, lineY, textPaint)
                lineY += 50f
                line = w
            }
        }
        if (line.isNotEmpty()) {
            canvas.drawText(line, 100f, lineY, textPaint)
        }

        // Page watermark at bottom right
        val watermarkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.LTGRAY
            alpha = 160
            textSize = 24f
            textAlign = Paint.Align.RIGHT
        }
        if (!isCover) {
            canvas.drawText("NovelMerge • Bölüm $chapterNum • Sayfa $pageNum", width - 80f, 1540f, watermarkPaint)
        } else {
            canvas.drawText("NovelMerge • Hazır Örnek Koleksiyon", width - 80f, 1540f, watermarkPaint)
        }

        return bitmap
    }

    private fun Bitmap.saveTo(file: File) {
        FileOutputStream(file).use { out ->
            compress(Bitmap.CompressFormat.JPEG, 92, out)
        }
    }
}
