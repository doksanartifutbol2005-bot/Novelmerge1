package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBackground = Color(0xFF0D0B16)
val DarkSurface = Color(0xFF161324)
val DarkSurfaceElevated = Color(0xFF221E36)
val DarkSurfaceBorder = Color(0xFF332E4D)

val NovelPrimary = Color(0xFFA855F7)        // Vivid Electric Violet
val NovelPrimaryLight = Color(0xFFC084FC)
val NovelSecondary = Color(0xFFEC4899)      // Radiant Manga Pink
val NovelSecondaryLight = Color(0xFFF472B6)
val NovelAccentGold = Color(0xFFF59E0B)     // Warm Amber Star Gold
val NovelAccentCyan = Color(0xFF06B6D4)

val TextPrimaryDark = Color(0xFFF3F4F6)
val TextSecondaryDark = Color(0xFF9CA3AF)
val TextMuted = Color(0xFF6B7280)

val LightBackground = Color(0xFFF8F9FA)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceElevated = Color(0xFFF1F3F5)
val LightPrimary = Color(0xFF7E22CE)
