package com.example.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.NovelRepository
import com.example.model.Chapter
import com.example.model.NovelPage
import com.example.model.NovelWork
import com.example.model.PendingArchiveItem
import com.example.model.ReaderSettings
import com.example.util.NaturalOrderComparator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import java.io.OutputStream
import java.util.UUID

enum class AppScreen {
    LIBRARY,
    MERGE_STUDIO,
    CHAPTER_LIST,
    READER
}

class NovelViewModel(application: Application) : AndroidViewModel(application) {

    val repository = NovelRepository(application.applicationContext)

    private val _currentScreen = MutableStateFlow(AppScreen.LIBRARY)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    val novels: StateFlow<List<NovelWork>> = repository.novels
    val readerSettings: StateFlow<ReaderSettings> = repository.readerSettings

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _isGridView = MutableStateFlow(true)
    val isGridView: StateFlow<Boolean> = _isGridView.asStateFlow()

    // Filtered novels based on search query
    val filteredNovels = combine(novels, searchQuery) { list, query ->
        if (query.isBlank()) list
        else list.filter { it.title.contains(query, ignoreCase = true) || it.description.contains(query, ignoreCase = true) }
    }

    // Detail & Reading state
    private val _selectedNovel = MutableStateFlow<NovelWork?>(null)
    val selectedNovel: StateFlow<NovelWork?> = _selectedNovel.asStateFlow()

    private val _chapters = MutableStateFlow<List<Chapter>>(emptyList())
    val chapters: StateFlow<List<Chapter>> = _chapters.asStateFlow()

    private val _currentReadingChapter = MutableStateFlow<Chapter?>(null)
    val currentReadingChapter: StateFlow<Chapter?> = _currentReadingChapter.asStateFlow()

    private val _currentChapterPages = MutableStateFlow<List<NovelPage>>(emptyList())
    val currentChapterPages: StateFlow<List<NovelPage>> = _currentChapterPages.asStateFlow()

    private val _currentReadingPageIndex = MutableStateFlow(0)
    val currentReadingPageIndex: StateFlow<Int> = _currentReadingPageIndex.asStateFlow()

    // Batch Merge Studio State
    private val _pendingArchives = MutableStateFlow<List<PendingArchiveItem>>(emptyList())
    val pendingArchives: StateFlow<List<PendingArchiveItem>> = _pendingArchives.asStateFlow()

    private val _suggestedNovelTitle = MutableStateFlow("")
    val suggestedNovelTitle: StateFlow<String> = _suggestedNovelTitle.asStateFlow()

    private val _isMerging = MutableStateFlow(false)
    val isMerging: StateFlow<Boolean> = _isMerging.asStateFlow()

    private val _mergeProgress = MutableStateFlow(0f)
    val mergeProgress: StateFlow<Float> = _mergeProgress.asStateFlow()

    private val _mergeStatusText = MutableStateFlow("")
    val mergeStatusText: StateFlow<String> = _mergeStatusText.asStateFlow()

    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    init {
        viewModelScope.launch {
            repository.initialize()
        }
    }

    fun navigateTo(screen: AppScreen) {
        _currentScreen.value = screen
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun toggleGridView() {
        _isGridView.value = !_isGridView.value
    }

    fun clearUserMessage() {
        _userMessage.value = null
    }

    fun setSuggestedTitle(title: String) {
        _suggestedNovelTitle.value = title
    }

    // Archive Queue Management
    fun addArchiveUris(files: List<Pair<Uri, String>>) {
        val current = _pendingArchives.value.toMutableList()
        val startIndex = current.size

        val newItems = files.mapIndexed { idx, (uri, name) ->
            val detectedIndex = NaturalOrderComparator.extractChapterNumber(name, startIndex + idx + 1)
            val title = NaturalOrderComparator.cleanChapterTitle(name, detectedIndex)
            PendingArchiveItem(
                id = UUID.randomUUID().toString(),
                uri = uri,
                fileName = name,
                fileSizeBytes = 0L,
                detectedChapterIndex = detectedIndex,
                customChapterTitle = title
            )
        }

        current.addAll(newItems)
        // Sort entire queue naturally based on detected chapter index and filename
        current.sortWith { a, b ->
            if (a.detectedChapterIndex != b.detectedChapterIndex) {
                a.detectedChapterIndex.compareTo(b.detectedChapterIndex)
            } else {
                NaturalOrderComparator().compare(a.fileName, b.fileName)
            }
        }

        _pendingArchives.value = current

        // If title empty, auto-detect base series name
        if (_suggestedNovelTitle.value.isBlank() && current.isNotEmpty()) {
            val sample = current.first().fileName.substringBeforeLast(".")
            val cleaned = sample.replace(Regex("(?i)(?:chapter|bolum|bölüm|ch|c|ep|#)\\s*\\d+.*"), "").trim()
                .replace("_", " ")
                .replace("-", " ")
                .trim()
            if (cleaned.isNotBlank()) {
                _suggestedNovelTitle.value = cleaned.replaceFirstChar { it.uppercase() }
            } else {
                _suggestedNovelTitle.value = "Yeni Görsel Roman"
            }
        }
    }

    fun movePendingItemUp(index: Int) {
        val list = _pendingArchives.value.toMutableList()
        if (index > 0 && index < list.size) {
            val item = list.removeAt(index)
            list.add(index - 1, item)
            _pendingArchives.value = list
        }
    }

    fun movePendingItemDown(index: Int) {
        val list = _pendingArchives.value.toMutableList()
        if (index >= 0 && index < list.size - 1) {
            val item = list.removeAt(index)
            list.add(index + 1, item)
            _pendingArchives.value = list
        }
    }

    fun removePendingItem(id: String) {
        _pendingArchives.value = _pendingArchives.value.filterNot { it.id == id }
    }

    fun updatePendingItemTitle(id: String, newTitle: String) {
        _pendingArchives.value = _pendingArchives.value.map {
            if (it.id == id) it.copy(customChapterTitle = newTitle) else it
        }
    }

    fun clearPendingArchives() {
        _pendingArchives.value = emptyList()
        _suggestedNovelTitle.value = ""
    }

    fun startBatchMerge(title: String, description: String) {
        val items = _pendingArchives.value
        if (items.isEmpty()) {
            _userMessage.value = "Lütfen birleştirilecek en az bir chapter arşivi seçin."
            return
        }

        _isMerging.value = true
        _mergeProgress.value = 0f
        _mergeStatusText.value = "Birleştirme başlatılıyor..."

        viewModelScope.launch {
            try {
                val createdNovel = repository.createMergedNovel(
                    title = title.ifBlank { "Birleştirilmiş Görsel Roman" },
                    description = description,
                    pendingChapters = items
                ) { progress, status ->
                    _mergeProgress.value = progress
                    _mergeStatusText.value = status
                }

                _isMerging.value = false
                clearPendingArchives()
                _userMessage.value = "'${createdNovel.title}' başarıyla tek parçaya dönüştürüldü ve kütüphaneye eklendi!"
                // Open chapter list of the newly merged novel
                openNovel(createdNovel.id)
            } catch (e: Exception) {
                _isMerging.value = false
                _userMessage.value = "Hata oluştu: ${e.localizedMessage ?: "Bilinmeyen arşiv hatası"}"
            }
        }
    }

    fun openNovel(novelId: String) {
        viewModelScope.launch {
            val novel = novels.value.find { it.id == novelId }
            _selectedNovel.value = novel
            val chs = repository.getChapters(novelId)
            _chapters.value = chs
            _currentScreen.value = AppScreen.CHAPTER_LIST
        }
    }

    fun startReading(novelId: String, chapterId: String? = null, initialPageIndex: Int = 0) {
        viewModelScope.launch {
            var novel = novels.value.find { it.id == novelId } ?: return@launch
            _selectedNovel.value = novel

            val chs = repository.getChapters(novelId)
            _chapters.value = chs

            val targetChapterId = chapterId ?: novel.lastReadChapterId ?: chs.firstOrNull()?.id ?: return@launch
            val targetChapter = chs.find { it.id == targetChapterId } ?: chs.firstOrNull() ?: return@launch

            val pages = repository.getChapterPages(novelId, targetChapter.id)
            _currentReadingChapter.value = targetChapter
            _currentChapterPages.value = pages

            val validPageIndex = initialPageIndex.coerceIn(0, (pages.size - 1).coerceAtLeast(0))
            _currentReadingPageIndex.value = validPageIndex

            repository.saveReadingProgress(novelId, targetChapter.id, validPageIndex)
            _currentScreen.value = AppScreen.READER
        }
    }

    fun onPageChanged(newPageIndex: Int) {
        val novel = _selectedNovel.value ?: return
        val chapter = _currentReadingChapter.value ?: return
        val pages = _currentChapterPages.value
        if (newPageIndex in pages.indices) {
            _currentReadingPageIndex.value = newPageIndex
            viewModelScope.launch {
                repository.saveReadingProgress(novel.id, chapter.id, newPageIndex)
            }
        }
    }

    fun nextChapter() {
        val current = _currentReadingChapter.value ?: return
        val chs = _chapters.value
        val currentIndex = chs.indexOfFirst { it.id == current.id }
        if (currentIndex != -1 && currentIndex < chs.size - 1) {
            val next = chs[currentIndex + 1]
            startReading(next.novelId, next.id, 0)
        }
    }

    fun previousChapter() {
        val current = _currentReadingChapter.value ?: return
        val chs = _chapters.value
        val currentIndex = chs.indexOfFirst { it.id == current.id }
        if (currentIndex > 0) {
            val prev = chs[currentIndex - 1]
            startReading(prev.novelId, prev.id, 0)
        }
    }

    fun updateReaderSettings(settings: ReaderSettings) {
        repository.updateReaderSettings(settings)
    }

    fun toggleFavorite(novelId: String) {
        viewModelScope.launch {
            repository.toggleFavorite(novelId)
            _selectedNovel.value = novels.value.find { it.id == novelId }
        }
    }

    fun renameNovel(novelId: String, newTitle: String) {
        viewModelScope.launch {
            repository.renameNovel(novelId, newTitle)
            _selectedNovel.value = novels.value.find { it.id == novelId }
            _userMessage.value = "Başlık güncellendi: $newTitle"
        }
    }

    fun deleteNovel(novelId: String) {
        viewModelScope.launch {
            repository.deleteNovel(novelId)
            _selectedNovel.value = null
            _currentScreen.value = AppScreen.LIBRARY
            _userMessage.value = "Görsel roman kütüphaneden silindi."
        }
    }

    fun exportNovel(novelId: String, outputStream: OutputStream) {
        viewModelScope.launch {
            try {
                repository.exportNovelToStream(novelId, outputStream)
                _userMessage.value = "Tek parça CBZ arşivi başarıyla dışa aktarıldı!"
            } catch (e: Exception) {
                _userMessage.value = "Dışa aktarma başarısız: ${e.localizedMessage}"
            }
        }
    }

    fun loadDemoSample() {
        viewModelScope.launch {
            repository.initialize()
            _userMessage.value = "Örnek görsel roman kütüphaneye eklendi!"
        }
    }
}
